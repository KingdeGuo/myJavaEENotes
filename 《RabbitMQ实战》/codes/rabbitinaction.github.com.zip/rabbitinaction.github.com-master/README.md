RabbitMQ in Action Blog.

Post content &copy; 2010 Jason J. W. Williams &amp; Alvaro Videla.

HTML and CSS adopted from [Jekyll](http://github.com/mojombo/jekyll).